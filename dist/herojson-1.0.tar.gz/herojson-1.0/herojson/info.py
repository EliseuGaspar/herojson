
def __info__():
    print(
        """
        herojson

        --version : 1.0
        --author : Eliseu A. G. Gonçalves
        --create_date : 2023/04/15
        --documentation : https://eliseuspythonmodules.tk/herojson
        --updates_date : ---
        
        """
    )